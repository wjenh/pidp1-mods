This is an implementation of the Type 23 Drum memory.
Just copy to the IOTs directory and make in order to use it.
