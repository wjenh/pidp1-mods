This is an implementation of the BBN timesharing clock, only available on the PDP-1D.
It provides a millisecond clock that can be read, as well as providing a 32 msed and 1 minute sbs interrupt.
If sbs16 is enabled, a different channel can be assigned to each.

See the UsingTimesharingClock.md in the Docs directory for details.
