See the UsingDCS2.md information in the Docs directory.
The 3 example programs show various ways of handling the sockets.
