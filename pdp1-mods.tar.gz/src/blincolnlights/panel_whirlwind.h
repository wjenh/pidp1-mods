typedef struct Panel Panel;
struct Panel
{
	int sw[7];
	int lights[16];

	// for convenience
	int psw6;
};
