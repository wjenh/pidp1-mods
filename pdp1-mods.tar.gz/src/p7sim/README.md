Simulate a P7 phosphor CRT for old computer displays (PDP-1, PDP-6, ...).
WIP
