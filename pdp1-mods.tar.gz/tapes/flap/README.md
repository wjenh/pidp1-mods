FLAP
====

FLAP is an implementation of Forth for the PDP-1
that also includes a Lisp.

Both are fairly barebones at the moment, but the basics are working.

Because Lisp is implemented in Forth eval/apply are very slow.

The `lisp` word in Forth is a Lisp REPL.

More information and documentation will follow.
